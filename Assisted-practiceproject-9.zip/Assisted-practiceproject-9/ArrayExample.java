
import java.util.Scanner;

public class ArrayExample
{
	public static void main(String[] args) {
		int n,i;
		System.out.println("Enter number of elements");
		Scanner sc= new Scanner(System.in); 
		n=sc.nextInt();
		System.out.println("Enter "+n+" elements");
		int arr[]= new int[n];
		for(i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		for(i=0;i<n;i++)
		{
			if(arr[i]%2==0)
			{
				System.out.println(arr[i]+" is a even number");
			}
			else
			{
				System.out.println(arr[i]+" is a odd number");
			}
		}
	}
}
