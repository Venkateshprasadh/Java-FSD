
public class StudentdetailsArrayExample {
	int rollno;
	String name;
	double average,tamil,english,maths,science,social;
	public StudentdetailsArrayExample( int rollno,String name, double tamil, double english, double maths, double science,double social) {
		
		// TODO Auto-generated constructor stub
		this.english=english;
		this.tamil=tamil;
		this.maths=maths;
		this.social=social;
		this.science=science;
		this.name=name;
		this.rollno=rollno;
		
	}
	public void AvgPlusDisplay(int rollno,String name, double tamil, double english, double maths, double science,double social) {
		// TODO Auto-generated method stub
		this.average=(english+maths+tamil+science+social)/5;
		System.out.println("---------Report card-------------");
		System.out.println("Roll number : "+this.rollno);
		System.out.println("name        : "+this.name);
		System.out.println("Tamil       : "+this.tamil);
		System.out.println("english     : "+this.english);
		System.out.println("Maths       : "+this.maths);
		System.out.println("science	    : "+this.science);
		System.out.println("social      : "+this.social);
		System.out.println("Average mark: "+this.average);
		
	}
	
	public static void main(String[] args) {
		
		StudentdetailsArrayExample[] arr= new StudentdetailsArrayExample[3];
		
		arr[0]=new StudentdetailsArrayExample(12341,"ravi",90,100, 80, 50, 60);
		arr[1]=new StudentdetailsArrayExample(12342,"kavi",90,70, 90.3, 50, 60);
		arr[2]=new StudentdetailsArrayExample(12343,"pavi",90,10, 89, 59, 67);
		
		int i;
		for(i=0;i<arr.length;i++)
		{
			arr[i].AvgPlusDisplay(arr[i].rollno, arr[i].name, arr[i].tamil, arr[i].english, arr[i].maths, arr[i].science, arr[i].social);
		}
		
	}

	
	

}
