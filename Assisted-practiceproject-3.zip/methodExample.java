
public class methodExample 
{
	double pi=3.14;
	void CircleArea(double r)//call by value //overloading 1 parameter  with argument without return type
	{
		double area;
		area=3.14*r*r;
		System.out.println("area of circle:"+area);
	}
	void RectangleaArea(double l, double b)// call by value // overloading 2 parameter with argument without return type
	{
		double area;
		area=l*b;
		System.out.println("area of circle:"+area);
	}
	double square(double s)  /// with argument with return type
	{
		double area=s*s;
		return area;
	}
	double pivalue()///with return type and without argument
	{
		return this.pi;
	}
	void pvalue() //without return type and without argument
	{
		System.out.println(pi);
	}
	public static void main(String[] args) {
		methodExample m =new methodExample();
		m.CircleArea(5);//call by vale //method overloading
		m.RectangleaArea(5, 4);
		double sqarea=m.square(2);
		System.out.println("Square area: "+sqarea);
		double pievalue=m.pivalue();
		System.out.println(pievalue);
		m.pvalue();
	}

}
