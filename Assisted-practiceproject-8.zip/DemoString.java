
public class DemoString {

	public static void main(String[] args) {
		String v1="hello welcome to java";
		String v2 = "String examples";
		String v3="same";
		String v4="name";
		
		System.out.println("String operations are as follows");
		System.out.println(v1.charAt(1));
		System.out.println(v1.codePointAt(1));
		System.out.println(v1.concat(v2));
		System.out.println(v1.codePointBefore(2));
		System.out.println(v1.codePointCount(0, 9));
		System.out.println(v3.equals(v4));
		System.out.println(v3.compareTo(v4));
		System.out.println(v3.replace("s", "d"));
		System.out.println(v4.toUpperCase());
		//creating mutable strings using string buffer
		StringBuffer strbuf = new StringBuffer("string buffer");
		strbuf.append(" example");
		System.out.println(strbuf);
		System.out.println(strbuf.length());
		strbuf.insert(21," is it correct?");
		System.out.println(strbuf);
		System.out.println(strbuf.indexOf("is"));
		System.out.println(strbuf.indexOf("ct"));
		strbuf.replace(22, 33, "is demonstrated");
		System.out.println(strbuf);
		strbuf.delete(22, 40);
		System.out.println(strbuf);
		StringBuffer gg= new StringBuffer("hello");
		System.out.println(gg.reverse());

		
		
	}
}

