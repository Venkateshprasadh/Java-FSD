import java.util.*;
public class MapExample 
{
 public static void main(String[] args) {
	//HashTable
	 System.out.println("------hashtable--------------");
	 Hashtable<Integer,String> hashtable = new Hashtable<Integer,String>();
	 hashtable.put(1111, "venkatesh");  
	 hashtable.put(1112, "Umamaheswari");  
	 hashtable.put(1113, "Shreenidhi");  
	 hashtable.put(1114, "Ramesh");
     System.out.println(hashtable);
     for(Map.Entry m:hashtable.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
     System.out.println("---------hashmap------------");
     HashMap<Integer,String> hashmap = new HashMap<Integer,String>();
	 hashmap.put(1111, "venkatesh");  
	 hashmap.put(1112, "Umamaheswari");  
	 hashmap.put(1113, "Shreenidhi");  
	 hashmap.put(1114, "Ramesh");
     System.out.println(hashmap);
     for(Map.Entry m:hashmap.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
     
     
     System.out.println("---------treemap---------");
     TreeMap<Integer,String> treemap=new TreeMap<Integer,String>();    
     treemap.put(1111, "venkatesh");    
     treemap.put(1112, "Umamaheswari");    
     treemap.put(1113, "Shreenidhi");   
     treemap.put(1114, "Ramesh");
     
     System.out.println(hashmap);  
     for(Map.Entry l:treemap.entrySet()){    
      System.out.println(l.getKey()+" "+l.getValue());    
     }    


}
}
