import java.util.regex.*;
import java.util.Scanner;
public class RegularExpression 
{
public static void main(String[] args) {
	Pattern pattern = Pattern.compile(".xx.");
	String s="pxxp";
	/*
	 * Scanner sc=new Scanner(System.in); System.out.println("enter string");
	 * s=sc.next();
	 */
	Matcher matcher = pattern.matcher(s);
	if(matcher.matches())
	{
		System.out.println("matched");
	}
	else
	{
		System.out.println("not matched");
	}
	
	
	
	System.out.println(Pattern.matches("[xyz]","ahat"));//false ahat not in xyz
	System.out.println(Pattern.matches("[xyz]","x"));//true present
	System.out.println(pattern.matches("[xyz]","xxyyzzz"));//false repeating more than 1 time
	
	System.out.println("--------quantifiers-------");
	System.out.println(pattern.matches("[ayz]?","a"));
	System.out.println(pattern.matches("[xyz]+", "x"));
	
	
}
}
