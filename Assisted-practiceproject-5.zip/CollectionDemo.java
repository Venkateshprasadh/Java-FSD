import java.util.*;
public class CollectionDemo {
	public static void main(String[] args) {
		LinkedList<String> li=new LinkedList<String>();
		li.add("hari");
		li.add("surya");
		li.add("jillu");
		Iterator<String> itr=li.iterator();
		System.out.println("linked list");
		System.out.println(li);
		//Iterator itr1=li.iterator();  
		//while(itr1.hasNext()){  
		//System.out.println(itr1.next());  
		ArrayList<String> al=new ArrayList<String>();
		al.add("english");
		al.add("tamil");
		al.add("maths");
		System.out.println("Array list:");
		Collections.sort(al);
		System.out.println(al);
		
		
		Vector<String> v=new Vector<String>();
		v.add("bndia");
		v.add("capan");
		v.add("ahina");
		System.out.println("vector:");Collections.sort(v);
		System.out.println(v);
		
		Stack<String> st=new Stack<String>();
		st.push("trichy");
		st.push("salem");
		st.push("karur");
		System.out.println("stack:");
		System.out.println(st);
		System.out.println("poping last item");
		st.pop();
		System.out.println(st);
		
		}  
		
	}
	


