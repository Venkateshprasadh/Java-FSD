class outer{
	 int salary=90000;
	class inner{
		int bonous=5000;
		
	}
}
public class InnerClass 
{
	public static void main(String[] args) {
		outer o =new outer();
		outer.inner in= o.new inner();
		int newsalary=o.salary+in.bonous;
		System.out.println("new salary is: "+newsalary);
	}
	
	
	
}
