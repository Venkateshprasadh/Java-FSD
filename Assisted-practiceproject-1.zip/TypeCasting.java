
public class TypeCasting {
 public static void main(String[] args) {
	char a='V';
	//implicit conversion
	int integer=a;float floater=a;
	System.out.println("implicit conversion or widening");
	System.out.println("as a integer "+integer+ "\nas a float "+floater);
	System.out.println("-----------------------------------------");
	//explicit conversion
	double u=10.10;
	int x=(int)u;
	System.out.println("explicit conversion or narrowing");
	System.out.println("as a int "+u+"\nas a float "+x);
}
}
