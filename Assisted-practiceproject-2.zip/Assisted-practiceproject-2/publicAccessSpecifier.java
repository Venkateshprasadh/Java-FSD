
public class publicAccessSpecifier {
	public void output()
	{
		System.out.println("this is public Access specifier");
	}
	public static void main(String[] args) {
		 protectedAccessSpecifier proc= new  protectedAccessSpecifier();
		 proc.output();
		 //pri.output(); ///ERROR accessible only within privareAccessSpecifier class
		 
		
	}

}
