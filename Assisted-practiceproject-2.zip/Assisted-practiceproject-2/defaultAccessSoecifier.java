
public class defaultAccessSoecifier {
 
	void output()
	{
		System.out.println("Default Access specifier");
	}
	public static void main(String[] args) {
		defaultAccessSoecifier d=new defaultAccessSoecifier();
		d.output();
		
	}
}
