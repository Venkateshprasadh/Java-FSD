
public class privateAccessSpecifier {
	private void output()
	{
		System.out.println("private access modifier");
		
	}
	public static void main(String[] args) {
		privateAccessSpecifier pri = new privateAccessSpecifier();
		publicAccessSpecifier pub= new publicAccessSpecifier();
		pub.output();//public so accesible even outside class,outside package,within package
		pri.output();//can be called only within this class
	}
	

}
