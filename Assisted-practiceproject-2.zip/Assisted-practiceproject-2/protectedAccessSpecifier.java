
public class protectedAccessSpecifier {
	protected void output()
	{
		System.out.println("this is protected");
	}
	public static void main(String[] args) {
		defaultAccessSoecifier d=new defaultAccessSoecifier();
		d.output();//accessing defaultAccessSpecifier's method within the package 
	}
}
