
public class Constuctor {
	int id;
	String name;

	Constuctor(){ //default constructor
		id=11;
		name="raman";
		System.out.println("Default constructor is called and values are");
		System.out.println("id:"+id+"\tname:"+name);
		}
	Constuctor(int eid, String ename) //parameterized constructor
	{
		this.id=eid;
		this.name=ename;
		System.out.println("parameterized constructor is called and values are");
		System.out.println("id:"+id+"\tname:"+name);
	}
	public static void main(String[] args) {
		 Constuctor c=new Constuctor(15,"jillu"); 
		//Constuctor c=new Constuctor();//default conntructor is called automatically in creation of class object
		
	}
}
